package com.cg.pms.dao;

import java.util.List;

import com.cg.pms.dto.Product;
import com.cg.pms.exceptions.PMSException;
import com.cg.pms.utility.PMSUtil;

public class IprouctDaoImpl implements IProductDao {

	@Override
	public int addProduct(Product product) throws PMSException {

		int id = (int) (Math.random() * 1000);
		product.setProductId(id);

		List<Product> products = PMSUtil.getList();
		products.add(product);

		// PMSUtil.getList().add(product);

		return id;
	}

	@Override
	public List<Product> getAllProducts() throws PMSException {
		return PMSUtil.getList();
	}

	@Override
	public Product searchProduct(int productId) throws PMSException {

		List<Product> list = PMSUtil.getList();
		Product productData = null;
		boolean flag = false;

		for (Product product : list) {
			if (product.getProductId() == productId) {
				productData = product;
				flag = true;
				break;
			}
		}
		if (flag == false) {
			throw new PMSException("No product present with the given id");
		}

		return productData;
	}

}
