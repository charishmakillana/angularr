import { Injectable } from '@angular/core';
import{Istore} from './home/store';

import { Observable } from 'rxjs';
import{HttpClient} from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class StorelistService {
  url : string = "assets/products.json";
  constructor(private http : HttpClient) {}
  getItems () : Observable<Istore []>
  { 
 
return this.http.get<Istore []>(this.url);

  }
}
