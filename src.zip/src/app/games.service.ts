import { Injectable } from '@angular/core';
import{HttpClient} from '@angular/common/http'
import{IPlay} from './play/games';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GamesService {
  url : string = "assets/GameList.json";
  constructor(private http : HttpClient) {}
  getList () : Observable<IPlay []>
  { 
 
return this.http.get<IPlay []>(this.url);

  }
}
