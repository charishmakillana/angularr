import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddproductComponent } from './addproduct/addproduct.component';
import { BuyproductComponent } from './buyproduct/buyproduct.component';
import { PlayComponent } from './play/play.component';

const routes: Routes = [
  {path:'',component:PlayComponent},
  {path:'app-play',component:PlayComponent},
  {path:'app-addproduct', component:AddproductComponent},
  {path:'app-buyproduct', component:BuyproductComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
