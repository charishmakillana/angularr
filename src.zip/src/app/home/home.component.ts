import { Component, OnInit } from '@angular/core';
import{Istore} from './store';
import { StorelistService } from '../storelist.service';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  stores : Istore[];
  isUpdate  : boolean = false;
  id: number;
  pname : string;
  pamount : number;
  pquantity : number;
  totalamount:number=20000;
balance: number=0;
    constructor(private service : StorelistService) { }
  
    ngOnInit() {
      this.service.getItems().subscribe(data=>this.stores=data);
    }
   update (s: Istore)
   {
     this.id=s.id;
     this.pname=s.pname;
     this.pamount=s.pamount;
     this.pquantity=s.pquantity;
     this.isUpdate=true;
   }
  
   updateDetails()
   {
     let arr = this.stores.filter(p=>p.id !=this.id);
     arr.push({id : this.id ,pname: this.pname,pamount : this.pamount,pquantity : this.pquantity})
     this.stores = arr;
     this.isUpdate =false;
   }
   delete(st : Istore)
   {
     let arr = this.stores.filter(p=>p.id !=st.id);
     this.stores = arr;
   }
   flag:boolean=false;

   buy(pamt:number){
    this.flag=!this.flag;
     
    this.balance=this.totalamount-pamt;
   
    console.log(this.balance);
    alert(this.balance+"is your remaining");
   return  this.balance;
     
   }
  }
  