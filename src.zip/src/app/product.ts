export class iproduct{
    id:number;
    name:string;
    price:number;
    quantity:number;
} 