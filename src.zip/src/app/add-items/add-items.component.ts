import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Istore } from '../home/store';
import { StorelistService } from '../storelist.service';

@Component({
  selector: 'app-add-items',
  templateUrl: './add-items.component.html',
  styleUrls: ['./add-items.component.css']
})
export class AddItemsComponent implements OnInit {

  userform : FormGroup = new FormGroup({
    id : new FormControl(),
    pname  : new FormControl("",[Validators.required,Validators.minLength(6)]),
    pamount : new FormControl(null,[Validators.required,Validators.pattern("^[0-9]{4}")]),
    pquantity :new FormControl()
  });
  stores : Istore[];
  
  constructor(private service : StorelistService) { }

  ngOnInit() {
    this.userform =  new FormGroup({
      id : new FormControl(),
      pname  : new FormControl("",[Validators.required,Validators.minLength(3), Validators.maxLength(8)]),
      pamount : new FormControl(null,[Validators.required,Validators.pattern("[0-9]{3,4}")]),
      pquantity  :new FormControl()
    });
    this.service.getItems().subscribe(data=>this.stores=data);
  }
  onSubmit(obj:any)
  {
   // console.log(obj);
   this.stores.map(p=> p.pname).forEach(p=>console.log(p));
   let arr = this.stores.filter(p=>p.id==obj.id);
   if( arr.length >  0)
   {
     alert("Id already Exists")
   }
   else{
    obj.pamount=obj.pamount-100;
    alert("subscription charge is deducted");
    this.stores.push({id:obj.id,pname: obj.pname,pamount: obj.pamount,pquantity :obj.pquantity});
   }
   
  }

}
