export interface IPlay{
    gameId:number;
    gameName:string;
    gamePrice:number;
}