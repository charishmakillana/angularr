import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { igame } from '../game';

@Component({
  selector: 'app-play',
  templateUrl: './play.component.html',
  styleUrls: ['./play.component.css']
})
export class PlayComponent implements OnInit {

  constructor(private service:ProductService) { }

  list:Array<igame>[]=this.service.productList;

  ngOnInit() {
  }

}
